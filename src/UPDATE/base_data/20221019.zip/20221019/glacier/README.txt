file format conventions for glacier-wide mass balance data
----------------------------------------------------------

file-name convention based on evaluation of different time-systems:
   <glaciername>_fix.dat     :  fixed date for 1.Oct - 30.Apr - 30.Sep
   <glaciername>_obs.dat     :  actual dates of field measurements
   <glaciername>_strat.dat   :  stratigraphic period defined by min - max - min

   <glaciername> : short VAW working name (no special characters)


File-structure (ASCII):
    header-block (4 lines, # at begin, fields separated by ';'):
      (1) data-type, gl-name, gl-number, method, # e_bands, h_min_eb, h_max_eb
      (2) column headers
      (3) units (yyyymmdd, mm w.e., m asl., %, km2,  m asl., mm w.e., km2)
      (4) analysis / copyright: source institution, revision year(date), bibliographic ref, url
	  
    data-block with 12+3*n columns (where n=number of elevation bands):
      id, date0, date_f, date_s, date1, B_w, B_a, ELA, AAR, A, h_min, h_max,
      b_w_eb_i, b_a_eb_i, A_eb_i

    fortran-format-string:
      data-block   '(i1,a9,a5,a5,a9,x,2i7,i6,i4,f10.5,2i6,2(#a7),#f9.5)'

    unknown / no-data value:
      id                            :  0
      date0, date_f, date_s, date1  :  0000000, 0000
      all other columns             :  NaN


   fields/columns description with units:

     data-type :  Mass Balance
     gl-name   :  Glacier name  (official spelling in iso-latin)
     gl-number :  VAW glacier id
     method    :  gl = glacier-wide MB-analysis
     # e_bands :  number of elevation bands
     h_min_eb  :  elevation of lower bound of lowest elevation band  [m asl]
     h_max_eb  :  elevation of upper bound of highest elevation band  [m asl]
     revision  :  year(date) of last revision  [yyyy(mmdd)]

     id        :  Method of evaluation (definitions see below)
     date0     :  date of begin of period  [yyyymmdd]
     date_f    :  date of minimum in fall = begin of winter period  [mmdd]
     date_s    :  date of end of winter period (spring measurements, maximum in spring)  [mmdd]
     date1     :  date of end of period  [yyyymmdd]
     B_w       :  glacier-wide winter balance  [mm w.e.]
     B_a       :  glacier-wide annual balance  [mm w.e.]
     ELA       :  equilibrium-line-altitude  [m asl]
     AAR       :  accumulation-area-ratio  [%]
     A         :  area  [km2]
     h_min     :  minimum elevation  [m asl]
     h_max     :  maximum elevation  [m asl]
     b_w_eb_i  :  n columns with area-mean winter balance of each elevation band  [mm w.e.]
     b_a_eb_i  :  n columns with area-mean annual balance of each elevation band  [mm w.e.]
     A_eb_i    :  n columns with area of each elevation band  [km2]


   id for method of analysis:
     0 : not defined / unknown
     1 : analysis of seasonal stake observations   (b_w & b_a)
     2 : analysis of annual stake observations but not close to the end of the
         period   (b_w)
     3 : analysis of annual stake observations   (b_a)
     4 : combined analysis of seasonal stake observations with volume
         change   (b_w & b_a & dV)
     5 : combined analysis of annual stake observations within the period
         with volume change   (b_w & dV)
     6 : combined analysis of annual stake observations with volume
         change   (b_a & dV)
     7 : reconstruction from volume change analysis (dV)
     8 : reconstruction from volume change with help of stake data  (dV & b_a/b_w)
     9 : no measurements, only model results

